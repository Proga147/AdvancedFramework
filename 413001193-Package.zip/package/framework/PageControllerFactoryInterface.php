<?php
namespace myFramework;


interface PageControllerFactoryInterface
{

static public function makePageController(String $controllerName); //interface for creating a model


}
