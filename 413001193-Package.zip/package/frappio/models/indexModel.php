<?php

namespace myFramework;

class indexModel extends Model {

 public function findAll(){}
 public function findOne(string $table,array $data){}
 public function update(string $table,array $data){}
 public function delete(string $table,$data){}
 public function add(array $data){}

}
