<?php
namespace myFramework;


class coursesController extends PageController {

public function __construct()
{
  $this->makeModel('coursesModel'); //make the coursesModel
}

public function index()
{
  $view = $this->makeView('courses'); //make the view object and store it in the @view variable
  $model = $this->getModel(); //store the model in the $model varibale for optional queries
  $view->setModel($model); //set the model in the view to retrieve or modify any data.
  $view->run();
}





} //end coursesController
