<?php
namespace myFramework;

class confirmController extends PageController {

public function __construct()
{
  $model = $this->makeModel('confirmModel');
}

public function confirm($params)
{
  $view = $this->makeView('confirm');
  $model = $this->getModel();
  $data=$model->delete(" ",$params);
  $view->run();
}


}
