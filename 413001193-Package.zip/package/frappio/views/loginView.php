<?php

namespace myFramework;

class loginView extends View
{


	public function run()
	{

		$user = Registry::get('user'); //get the User
		$errors = Registry::get("Auth"); //get the Authentication
    $errors = $errors->getErrors();
	  $userdata = $this->getData( );

    //echo print_r($userdata);


	  if(!empty($userdata))
		{
			 $user->init($userdata);
		}

		if($user->isUserLoggedIn() == true)
		{
			$this->addVars('title','Login');
			$this->addVars('errors',$errors);
			$this->addVars('userdata',$userdata);
			$this->addVars("status","loggedIn");
			header('Location: /home');
		}
    else {
    	$this->addVars("status","not logged In");
			$this->addVars('title','Login');
			$this->addVars('errors',$errors);
			$this->addVars('userdata',$userdata);
			$this->render();
    }

	   //render the view

	}


}
