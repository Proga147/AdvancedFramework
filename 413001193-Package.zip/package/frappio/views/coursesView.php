<?php
namespace myFramework;


class coursesView extends View {


  public function run()
  {
    $user = Registry::get('user');
    $errors = Registry::get("validator"); //get the Authentication
    $errors = $errors->getErrors();
    $model = $this->getModel();
    $courses = $model->findAll();

    if($user->isUserLoggedIn() == true)
    {
      $profile = $user->allInfo();
      $this->addVars("status","loggedIn");
      $this->addVars("userdata",$profile);
    }
    else {
      $this->addVars("status","not logged In");
    }

    $this->addVars('title','Courses');
    $this->addVars('errors',$errors);
    $this->addVars('courses',$courses);
    $this->render();   //render the view

  }



}
