<?php
namespace myFramework;

interface FrontControllerInterface
{
  public function init();
  public function run();
}
