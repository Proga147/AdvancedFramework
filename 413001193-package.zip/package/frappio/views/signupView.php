<?php
namespace myFramework;

class SignUpView extends View
{

	public function run()
	{
	$user = Registry::get('user'); //get the User
	$errors = Registry::get("validator"); //get the Authentication
	$errors = $errors->getErrors();


	if(!empty($userdata))
	{
		 $user->init($userdata);
	}
	if($user->isUserLoggedIn() == true)
	{
		$this->addVars("status","loggedIn");
	}
	else {
		$this->addVars("status","not logged In");
	}

  $user = $this->getData();
	$this->addVars('title','SignUp');
	$this->addVars('errors',$errors);
	$this->render();   //render the view


	}
}
