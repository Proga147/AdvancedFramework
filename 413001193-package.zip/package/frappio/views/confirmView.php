<?php
namespace myFramework;

class confirmView extends View {

  public function run()
  {
    $user = Registry::get('user');
    $errors = Registry::get("validator"); //get the Authentication
    $errors = $errors->getErrors();
    $profile = $user->allInfo();

    $this->addVars("userdata",$profile);
    $this->addVars("status","loggedIn");
    $this->addVars('title','Confirm');
    $this->addVars('errors',$errors);

    $this->render();   //render the view

  }





}
