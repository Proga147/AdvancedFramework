<?php
namespace myFramework;


class indexView extends View
{

  public function run()
  {
    $user = Registry::get('user'); //get the User
    $errors = Registry::get("Auth"); //get the Authentication
    $errors = $errors->getErrors();
    $userdata = $this->getData( );
    $profile = $user->allInfo();

    if(!empty($userdata))
    {
      $user->init($userdata);
    }
    if($user->isUserLoggedIn() == true)
    {
      $this->addVars("status","loggedIn");
    }
    else {
      $this->addVars("status","not logged In");
    }

    $this->addVars('title','Home');
    $this->addVars('errors',$errors);
    $this->addVars('userdata',$profile);
    $this->render();   //render the view

  }


}
