<?php
namespace myFramework;

class homeController extends PageController {


public function __construct()
{
   $this->makeModel('indexModel');  // make the homeModel

}

public function index ( )
{
  
 $view =$this->makeView("index");
 $model = $this->getModel();
 $view->setModel($model);
 $view->run();
}



}


//to be Placed in the frappio Directory
