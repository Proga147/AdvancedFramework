<?php
namespace myFramework;

class Authentication implements AuthenticationInterface
{
  use ErrorHandler;

  private static $instance;

  static public function getInstance() :AuthenticationInterface
  {
    if(empty(self::$instance))
    {
      self::$instance = new self();
      return self::$instance;
    }
    else {
      return self::$instance;
    }

  }

  static public function authenticate (User $user, int $mask): array {
    if(!is_numeric($mask)) {
      return array();
    }
    $return = array();
    while ($mask > 0) {
      for($i = 0, $n = 0; $i <= $mask; $i = 1 * pow(2, $n), $n++) {
        $end = $i;
      }
      $return[] = $end;
      $mask = $mask - $end;


    }
    sort($return);
    return $return;
  }

  static public function validateLogin($user , $password)
  {

    $validator = Registry::get("validator");

    if($validator->isPasswordValid($password) && $validator->isEmailValid($user))
    {
      echo "Email and Password Correctly entered";
      //can return true so the user can login
    }
    else {

      $errors = $validator->getErrors();

      foreach($errors as $error)
      {
        print_r($errors);
        echo "<br>";
        echo $error ."<br>";
      }
    }

  } // end validateLogin


} //end Authentication
