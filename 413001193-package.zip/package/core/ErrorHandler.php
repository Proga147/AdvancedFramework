<?php
namespace myFramework;

trait ErrorHandler {

private $_errors = array();

public function setError($msg = " ")
{
  array_push($this->_errors,$msg) ;
}

public function getErrors() :array
{
    return $this->_errors;
}

public function clearErrors()
{
  $this->_errors[] = null;
}


}
