<?php
namespace myFramework;

class Router implements RouterInterface
{
  protected $controller= MYFRAMEWORK."homeController";
  protected $action="index";
  protected $params = [];
  protected $route = [];

  public function __construct()
  {

    $this->parseUri();


  }

  public function parseUri()
  {
    $request = trim($_SERVER['REQUEST_URI'],'/');


    if(!empty($request))
    {
      $url = explode('/',$request);

      if(isset($url[0]))
      {
        $this->route["controller"]=$this->setController($url[0]);
      }

      if(isset($url[1]))
      {
        $this->route["action"]=$this->setAction($url[1]);
      }
      unset($url[0],$url[1]);

      if(!empty($url))
      {
        $this->route["params"]=$this->setParams(array_values($url));
      }

    }
    return $this->route;
  }


  public function setController($controller) {


    $controller = MYFRAMEWORK.strtolower($controller) ."Controller";


    if (!class_exists($controller)) {

      return $this->controller;
    }
    else {

      $this->controller = $controller;
      return $this->controller;
    }


  }

  public function setAction($action) {

    $reflector = new \ReflectionClass($this->controller);  // reports description about a class .
    if (!$reflector->hasMethod($action)) {
      return $this->action;
    }
    $this->action = $action;
    return $this->action;
  }

  public function setParams(array $params) {
    $this->params = $params;
    return $this->params;
  }

  public function getController()//get the controllers
  {
    $this->controller = $this->controller;
    return $this->controller;
  }

  public function getAction()  //get the action or method to be done
  {
    return $this->action;
  }

  public function getParams()  //gets the required parameters
  {
    return $this->params;
  }




}
