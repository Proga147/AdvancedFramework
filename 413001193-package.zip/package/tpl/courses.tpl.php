<main>
		<h1><?php echo $title ?></h1>
		<ul class="course-list">


			<?php foreach($courses as $key): ?>
			<li><div>
				<a href="#"><img src="<?php echo "../images/".$key['course_image']?>" alt="course image"></a>
				</div>
				<div>
				<a href="#"><span class="faculty-department"><?php echo $key['faculty_dept_name'] ?></span>
					<span class="course-title"><?php echo $key['course_name'] ?></span>
					<span class="instructor"><?php echo $key['instructor_name'] ?></span></a>
				</div>
				<div>
					<p>Get Curious.</p>
					<a href="/profile/start/<?php echo $key['course_id']?>" class="startnow-button startnow-btn">Start Now!</a>
				</div>
				</li>
			<?php endforeach; ?>



		</ul>
