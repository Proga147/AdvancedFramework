<main>
		<h1>Unenrollment Confirmed</h1>
		<ul id="unenroll-confirm">
			<li>
				<p>You have been removed from this course, please click <a href="/profile">this link</a> to return to your profile page</p>
			</li>

		</ul>
